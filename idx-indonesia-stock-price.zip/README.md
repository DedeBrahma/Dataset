# indonesia-stock-price
for research purpose only
